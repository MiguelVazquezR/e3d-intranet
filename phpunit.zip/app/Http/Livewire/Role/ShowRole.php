<?php

namespace App\Http\Livewire\Role;

use Livewire\Component;

class ShowRole extends Component
{
    public function render()
    {
        return view('livewire.role.show-role');
    }
}
